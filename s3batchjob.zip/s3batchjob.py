import json
import boto3
import uuid
import os

client_control = boto3.client('s3control', region_name='us-east-1')
source_bucket = os.environ.get('sourceBucket')
destination_bucket = os.environ.get('targetBucket')
manifest_file = os.environ.get('manifestFile')

def lambda_handler(event, context):
  try:
    #print(event)
    clientRequestToken=str(uuid.uuid4())
    print(clientRequestToken)
    operationDetails={
      "S3PutObjectCopy": {
        "TargetResource": 'arn:aws:s3:::s3sourcereportbatch',
        "MetadataDirective": "COPY",
        "StorageClass": "STANDARD",
        "BucketKeyEnabled": True,
        "TargetKeyPrefix": "Copy"
      }
    }
    reportDetails={
      "Format": "Report_CSV_20180820",
      "Bucket": "arn:aws:s3:::s3sourcereportbatch",
      "Enabled": True,
      "ReportScope": "AllTasks",
      "Prefix": "Report"
    }
    manifestDetails={
      "Spec": {
        "Format": "S3BatchOperations_CSV_20180820",
        "Fields":["Bucket","Key"]
      },
      "Location": {
        "ObjectArn": 'arn:aws:s3:::s3sourcereportbatch/Manifest/S3BatchOperations_CSV_20180820.csv',
        "ETag": '72f9553f3a1eb6a9a9ec5e621e40bfb7'
      }
    }
    response=client_control.create_job(
      AccountId='141066140288',
      ConfirmationRequired=False,
      Description='s3 batch ops job triggered by lambda',
      ClientRequestToken=clientRequestToken,
      Priority=1,
      RoleArn='arn:aws:iam::141066140288:role/BatchOperationsDestinationRoleCOPY',
      Operation=operationDetails,
      Report=reportDetails,
      Manifest=manifestDetails
    )
    print(response)
    return {
      "message": "True"
    }
  except Exception as exc:
    return {
      "message": "False",
      "Error": str(exc)
    }